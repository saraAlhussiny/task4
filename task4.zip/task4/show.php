
<?php

$v =$_GET["v"]*10;
$d =$_GET["d"];
$x =$_GET["x"];
$y =$_GET["y"];

switch ($d) {
  case 'R':
    $x2= $x + $v;
	$y2= $y;
	echo $x2;
    break;
  case 'L':
    $x2= $x - $v;
	$y2= $y;
	echo $x2;
    break;
  case 'F':
    $x2= $x;
	$y2= $y - $v;;
	echo $y2;
    break;
}


?>