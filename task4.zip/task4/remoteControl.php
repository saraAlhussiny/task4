<!DOCTYPE html>
<html>
<!------------------------------------------------------------------head---------->
 <head>
    <meta charset = "utf-8">
    <title>remoteontrol</title>
	
	<link rel = "stylesheet" href = "style.css">
	<script src="javas.js" type = "text/javascript"></script>
    <script src="https://code.iconify.design/1/1.0.4/iconify.min.js">   </script>

</head>

<!-------------------------------------------------------------------body--------->
<body>
<!-------------------------------------------------------------------------------header-->
    <main>  
	<center>
	<br><br>
   <label>Right</label> <input type=text onblur="funR(this.value);"> 
   <label> Forward</label> <input type=text onblur="funF(this.value);"> 
   <label>Left </label> <input type=text onblur="funL(this.value);"> <br> <br>
   <button onclick=window.location.reload(); >delete </button>
   <button>save </button>
   <button> start</button> 
    </center>
<table id="t" >
<tr style="border: 1px solid black">
<td style="border: 1px solid black">Destination &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td style="border: 1px solid black">Value</td>
</tr>
</table><br>
<style>
body{
	color: white;
}
#parent {
    width:400px;
    height:400px;
    border:1px solid #000;
    overflow:auto;
    margin-left: 550px; 
	
}

table {
  border-collapse: collapse;
    margin-left: 350px; 
    margin-top: 90px; 
}



</style>

<div id="parent">
 <canvas id="myCanvas" width="400" height="400" style="border:1px solid #d3d3d3; background: #D3D3D3">
Your browser does not support the HTML5 canvas tag.</canvas>
</div>
	
<script>
var x= 200;
var y= 400;

 function funF(value) {
var xhr = new XMLHttpRequest();
xhr.onreadystatechange = function () {
if (xhr.readyState == 4 && xhr.status == 200) {
var y2 = xhr.responseText;
var x2= x; 
drawArrow(x, y, x2, y2);
document.getElementById("t").insertAdjacentHTML("afterend", 
                "</td></tr><br>");
document.getElementById("t").insertAdjacentHTML("afterend", 
                value);
document.getElementById("t").insertAdjacentHTML("afterend", 
                "<td style='border: 1px solid black'>");		
document.getElementById("t").insertAdjacentHTML("afterend", 
                "<tr style='border: 1px solid black'><td style='border: 1px solid black'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Forward   &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>");				
x = x2;
y = y2;
}
}
var Destination = "F";
xhr.open("GET", "show.php?v=" + value+"&d="+Destination+ "&x=" +x+ "&y=" +y , true);
xhr.send(null);
}  

function funR(value) {
var xhr = new XMLHttpRequest();
xhr.onreadystatechange = function () {
if (xhr.readyState == 4 && xhr.status == 200) {
var x2 = xhr.responseText;
var y2 = y ;
drawArrow(x, y, x2, y2);
document.getElementById("t").insertAdjacentHTML("afterend", 
                "</td></tr><br>");
document.getElementById("t").insertAdjacentHTML("afterend", 
                value);
document.getElementById("t").insertAdjacentHTML("afterend", 
                "<td style='border: 1px solid black'>");		
document.getElementById("t").insertAdjacentHTML("afterend", 
                "<tr style='border: 1px solid black'><td style='border: 1px solid black'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Right   &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>");				
x = x2;
y = y2;
}
}
var Destination = "R";
xhr.open("GET", "show.php?v=" + value+"&d="+Destination+ "&x=" +x+ "&y=" +y , true);
xhr.send(null);
x= x2;
}

function funL(value) {
var xhr = new XMLHttpRequest();
xhr.onreadystatechange = function () {
if (xhr.readyState == 4 && xhr.status == 200) {
var x2 = xhr.responseText;
var y2 = y ;
drawArrow(x, y, x2, y2);
document.getElementById("t").insertAdjacentHTML("afterend", 
                "</td></tr><br>");
document.getElementById("t").insertAdjacentHTML("afterend", 
                value);
document.getElementById("t").insertAdjacentHTML("afterend", 
                "<td style='border: 1px solid black'>");		
document.getElementById("t").insertAdjacentHTML("afterend", 
                "<tr style='border: 1px solid black'><td style='border: 1px solid black'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Left   &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>");				
x = x2;
y = y2;
}
}
var Destination = "L";
xhr.open("GET", "show.php?v=" + value+"&d="+Destination+ "&x=" +x+ "&y=" +y , true);
xhr.send(null);
x= x2;
}

function drawArrow(fromx, fromy, tox, toy){
                //variables to be used when creating the arrow
                var c = document.getElementById("myCanvas");
                var ctx = c.getContext("2d");
                var headlen = 5;

                var angle = Math.atan2(toy-fromy,tox-fromx);

                //starting path of the arrow from the start square to the end square and drawing the stroke
                ctx.beginPath();
                ctx.moveTo(fromx, fromy);
                ctx.lineTo(tox, toy);
                ctx.strokeStyle = "#9162B1";
                ctx.lineWidth = 5;
                ctx.stroke();

                //starting a new path from the head of the arrow to one of the sides of the point
                ctx.beginPath();
                ctx.moveTo(tox, toy);
                ctx.lineTo(tox-headlen*Math.cos(angle-Math.PI/7),toy-headlen*Math.sin(angle-Math.PI/7));

                //path from the side point of the arrow, to the other side point
                ctx.lineTo(tox-headlen*Math.cos(angle+Math.PI/7),toy-headlen*Math.sin(angle+Math.PI/7));

                //path from the side point back to the tip of the arrow, and then again to the opposite side point
                ctx.lineTo(tox, toy);
                ctx.lineTo(tox-headlen*Math.cos(angle-Math.PI/7),toy-headlen*Math.sin(angle-Math.PI/7));

                //draws the paths created above
                ctx.strokeStyle = "#9162B1";
                ctx.lineWidth = 5;
                ctx.stroke();
                ctx.fillStyle = "#9162B1";
                ctx.fill();
            }				
</script>


     
      <!-------------------------------------------------------->
	</main>
   <!-------------------------------------------------------------------------footer-->
	<footer>
  	     
    </footer>
   <!----------------------------------------------------------------------------------->
</body>
<!--------------------------------------------------------------------------------------->
 </html>
<!---------------------------------------------------------------------------------->